
  # WaterHack Smart Irrigation Platform

  This is a code bundle for WaterHack Smart Irrigation Platform. The original project is available at https://www.figma.com/design/RYZJzOts8IKLofJ1jgMleE/WaterHack-Smart-Irrigation-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  